<script>
    document.addEventListener('DOMContentLoaded', () => {
      const form = document.getElementById('resource-form');
      const chartCtx = document.getElementById('consumption-chart').getContext('2d');
      const tipButton = document.getElementById('generate-tip');
      const tipText = document.getElementById('tip');

      // Data storage
      const data = {
        labels: [],
        water: [],
        energy: [],
        gas: []
      };

      // Chart setup
      const chart = new Chart(chartCtx, {
        type: 'line',
        data: {
          labels: data.labels,
          datasets: [
            {
              label: 'Apă (litri)',
              data: data.water,
              borderColor: 'blue',
              fill: false
            },
            {
              label: 'Energie (kWh)',
              data: data.energy,
              borderColor: 'green',
              fill: false
            },
            {
              label: 'Gaze (mc)',
              data: data.gas,
              borderColor: 'red',
              fill: false
            }
          ]
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: 'top',
            }
          }
        }
      });

      // Form submission handler
      form.addEventListener('submit', e => {
        e.preventDefault();
        const date = form.date.value;
        const water = parseFloat(form.water.value);
        const energy = parseFloat(form.energy.value);
        const gas = parseFloat(form.gas.value);

        data.labels.push(date);
        data.water.push(water);
        data.energy.push(energy);
        data.gas.push(gas);

        chart.update();
        form.reset();
      });

      // Tip generator
      const tips = [
        'Închide apa când te speli pe dinți.',
        'Stinge luminile când părăsești camera.',
        'Folosește electrocasnice eficiente energetic.',
        'Redu temperatura încălzirii cu un grad.',
        'Evită folosirea excesivă a apei calde.'
      ];

      tipButton.addEventListener('click', () => {
        const randomIndex = Math.floor(Math.random() * tips.length);
        tipText.textContent = tips[randomIndex];
      });
    });
  </script>